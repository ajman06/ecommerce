<?php
$db_host = "localhost";
$db_user = "root";
$db_pass = "";
$db_name = "testdemo";

$connection = mysqli_connect($db_host, $db_user, $db_pass, $db_name);

if($connection){
        echo "it works";
}
else {
die('error not connected'.mysqli_error());
}
?>